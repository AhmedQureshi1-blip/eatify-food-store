
import React from 'react';
import Layout from '@/components/layout/Layout';
import HeroSection from '@/components/sections/HeroSection';
import MenuSection from '@/components/sections/MenuSection';
import AboutUsSection from '@/components/sections/AboutUsSection';
import TestimonialsSection from '@/components/sections/TestimonialsSection';
import ContactSection from '@/components/sections/ContactSection';

function App() {
  return (
    <Layout>
      <HeroSection />
      <MenuSection />
      <AboutUsSection />
      <TestimonialsSection />
      <ContactSection />
    </Layout>
  );
}

export default App;
  