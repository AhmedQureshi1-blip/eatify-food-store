import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';

const HeroSection = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative bg-gradient-to-br from-eatify-primary-dark via-eatify-secondary-dark to-black min-h-screen flex items-center justify-center overflow-hidden section-padding pt-24 md:pt-32">
      <div className="absolute inset-0 opacity-10">
        <img 
          className="w-full h-full object-cover"
          alt="Abstract food pattern background"
         src="https://images.unsplash.com/photo-1520778166-93b06a2ce71a" />
      </div>
      
      <div className="container-custom mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
        >
          <h1 className="text-6xl md:text-8xl font-extrabold text-white font-heading mb-6 leading-tight shadow-text">
            Eatify
          </h1>
        </motion.div>
        <motion.p
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5, ease: "easeOut" }}
          className="text-2xl md:text-4xl text-eatify-text-medium font-semibold mb-10 shadow-text-sm"
        >
          Fast. Fresh. Fantastic!
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.8, type: "spring", stiffness: 120 }}
        >
          <Button
            size="lg"
            onClick={scrollToContact}
            className="bg-gradient-to-r from-eatify-accent-purple to-eatify-accent-blue hover:from-eatify-accent-blue hover:to-eatify-accent-purple text-white font-bold py-4 px-10 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 animate-pulse-glow"
          >
            <ShoppingCart className="mr-3 h-6 w-6" /> Order Now
          </Button>
        </motion.div>
      </div>
      <style jsx>{`
        .shadow-text {
          text-shadow: 2px 2px 8px rgba(0,0,0,0.7);
        }
        .shadow-text-sm {
          text-shadow: 1px 1px 5px rgba(0,0,0,0.5);
        }
      `}</style>
    </section>
  );
};

export default HeroSection;