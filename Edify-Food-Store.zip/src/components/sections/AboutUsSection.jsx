import React from 'react';
import { motion } from 'framer-motion';
import { ChefHat, Zap, Smile } from 'lucide-react';

const AboutUsSection = () => {
  const features = [
    {
      icon: <ChefHat className="h-12 w-12 text-primary" />,
      title: 'Fresh Ingredients',
      description: 'We believe in quality. That’s why we source the freshest local ingredients for all our meals.',
    },
    {
      icon: <Zap className="h-12 w-12 text-primary" />,
      title: 'Lightning Fast',
      description: 'Hungry? We get it. Our team works swiftly to get your delicious food ready in no time.',
    },
    {
      icon: <Smile className="h-12 w-12 text-primary" />,
      title: 'Customer Happiness',
      description: 'Your satisfaction is our priority. We strive to make every Eatify experience a happy one!',
    },
  ];

  return (
    <section id="about" className="bg-background section-padding">
      <div className="container-custom mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative rounded-xl shadow-2xl overflow-hidden">
              <img 
                className="w-full h-auto object-cover rounded-xl "
                alt="Eatify kitchen staff preparing food"
               src="https://images.unsplash.com/photo-1587480424274-e38568068434" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary rounded-full opacity-30 blur-2xl -z-10"></div>
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-secondary rounded-full opacity-20 blur-xl -z-10"></div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-extrabold font-heading mb-6 text-foreground">
              About <span className="gradient-text">Eatify</span>
            </h2>
            <p className="text-lg text-eatify-text-medium mb-8 leading-relaxed">
              Welcome to Eatify, where flavor meets speed! We're passionate about serving up delicious, high-quality fast food that doesn't compromise on taste or freshness. Our mission is simple: to make your mealtime fantastic, every single time. From sizzling burgers to crispy fries and delightful pizzas, we pour our hearts into every dish.
            </p>
            <div className="space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.5 }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  className="flex items-start space-x-4 p-4 bg-card rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="flex-shrink-0 p-3 bg-primary/10 rounded-full">{feature.icon}</div>
                  <div>
                    <h4 className="text-xl font-semibold text-eatify-text-light mb-1">{feature.title}</h4>
                    <p className="text-eatify-text-medium">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutUsSection;