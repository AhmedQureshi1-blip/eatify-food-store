import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Star } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Sarah L.',
    avatarPlaceholder: 'Happy female customer smiling',
    quote: "Eatify is my go-to for a quick and delicious meal! The burgers are always juicy and the fries perfectly crispy. Plus, the service is super friendly!",
    rating: 5,
    alt: 'Avatar of Sarah L.'
  },
  {
    id: 2,
    name: 'Mike P.',
    avatarPlaceholder: 'Male customer giving a thumbs up',
    quote: "The best pizza in town, hands down! I love the fresh ingredients and the speedy delivery. Eatify never disappoints.",
    rating: 5,
    alt: 'Avatar of Mike P.'
  },
  {
    id: 3,
    name: 'Jessica B.',
    avatarPlaceholder: 'Customer enjoying a meal',
    quote: "I'm obsessed with their fried chicken! It's so flavorful and crunchy. A perfect treat for any day of the week. Highly recommend!",
    rating: 4,
    alt: 'Avatar of Jessica B.'
  },
];

const TestimonialCard = ({ testimonial }) => {
  return (
    <motion.div
      className="h-full"
      whileHover={{ scale: 1.03 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <Card className="h-full flex flex-col justify-between p-6 md:p-8 bg-card shadow-xl rounded-2xl border-2 border-transparent hover:border-secondary transition-all duration-300">
        <CardContent className="p-0">
          <div className="flex items-center mb-4">
            <div className="w-16 h-16 rounded-full overflow-hidden mr-4 border-2 border-primary p-0.5">
               <img 
                className="w-full h-full object-cover rounded-full"
                alt={testimonial.alt}
               src="https://images.unsplash.com/photo-1678227547327-ec5745559b29" />
            </div>
            <div>
              <h4 className="text-xl font-semibold font-heading text-eatify-text-light">{testimonial.name}</h4>
              <div className="flex text-eatify-accent-blue">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} fill={i < testimonial.rating ? "currentColor" : "none"} className="w-5 h-5" />
                ))}
              </div>
            </div>
          </div>
          <p className="text-eatify-text-medium italic leading-relaxed">"{testimonial.quote}"</p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const TestimonialsSection = () => {
  return (
    <section id="testimonials" className="bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 section-padding">
      <div className="container-custom mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-5xl font-extrabold text-center mb-4 font-heading text-foreground"
        >
          What Our <span className="gradient-text">Customers Say</span>
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-center text-lg text-eatify-text-medium mb-16 max-w-2xl mx-auto"
        >
          We love our customers, and they love us too! Here’s what some of them have to say about their Eatify experience.
        </motion.p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
            >
              <TestimonialCard testimonial={testimonial} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;