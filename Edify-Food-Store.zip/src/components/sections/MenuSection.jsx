import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingBag } from 'lucide-react';

const menuItems = [
  {
    id: 1,
    name: 'Classic Cheeseburger',
    price: '$8.99',
    imagePlaceholder: 'Juicy classic cheeseburger with lettuce and tomato',
    description: 'A_juicy_beef_patty_with_melted_cheddar_cheese_fresh_lettuce_tomato_and_our_special_sauce_on_a_toasted_sesame_bun',
    alt: 'Classic Cheeseburger'
  },
  {
    id: 2,
    name: 'Pepperoni Pizza',
    price: '$12.50',
    imagePlaceholder: 'Slice of pepperoni pizza with melted cheese',
    description: 'A_crispy_thin-crust_pizza_topped_with_rich_tomato_sauce_mozzarella_cheese_and_spicy_pepperoni_slices',
    alt: 'Pepperoni Pizza'
  },
  {
    id: 3,
    name: 'Crispy French Fries',
    price: '$3.99',
    imagePlaceholder: 'Golden crispy french fries in a red container',
    description: 'Golden_brown_french_fries_cooked_to_perfection_lightly_salted_and_served_hot_and_crispy',
    alt: 'Crispy French Fries'
  },
  {
    id: 4,
    name: 'Fried Chicken Bucket',
    price: '$15.99',
    imagePlaceholder: 'Bucket of crispy fried chicken pieces',
    description: 'A_generous_bucket_of_our_signature_fried_chicken_marinated_in_secret_spices_and_fried_till_golden_and_crunchy',
    alt: 'Fried Chicken Bucket'
  },
  {
    id: 5,
    name: 'Cola Splash',
    price: '$2.50',
    imagePlaceholder: 'Refreshing cola drink with ice and bubbles',
    description: 'A_classic_refreshing_cola_served_ice-cold_the_perfect_thirst_quencher_with_your_meal',
    alt: 'Cola Splash'
  },
  {
    id: 6,
    name: 'Veggie Supreme Burger',
    price: '$9.50',
    imagePlaceholder: 'Delicious veggie burger with fresh vegetables',
    description: 'A_hearty_veggie_patty_loaded_with_fresh_greens_ripe_tomatoes_onions_and_a_tangy_vegan_mayo',
    alt: 'Veggie Supreme Burger'
  },
];

const MenuItemCard = ({ item }) => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <motion.div
      whileHover={{ y: -10, boxShadow: "0 20px 25px -5px hsl(var(--primary) / 0.3), 0 10px 10px -5px hsl(var(--primary) / 0.2)" }}
      transition={{ type: 'spring', stiffness: 300 }}
      className="w-full"
    >
      <Card className="overflow-hidden h-full flex flex-col group bg-card text-card-foreground border-2 border-transparent hover:border-primary transition-all duration-300 shadow-xl hover:shadow-2xl rounded-2xl">
        <CardHeader className="p-0">
          <div className="aspect-w-16 aspect-h-9 overflow-hidden">
            <img 
              className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500 ease-in-out"
              alt={item.alt}
             src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
          </div>
        </CardHeader>
        <CardContent className="pt-6 flex-grow">
          <CardTitle className="text-2xl font-bold text-eatify-dark group-hover:gradient-text transition-colors duration-300">{item.name}</CardTitle>
          <p className="text-sm text-eatify-text-medium mt-2 line-clamp-3">{item.description.replace(/_/g, ' ')}</p>
        </CardContent>
        <CardFooter className="flex justify-between items-center pt-4">
          <p className="text-2xl font-extrabold text-primary">{item.price}</p>
          <Button onClick={scrollToContact} variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white rounded-full transition-all transform group-hover:scale-105">
            <ShoppingBag className="mr-2 h-5 w-5" /> Order
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

const MenuSection = () => {
  return (
    <section id="menu" className="bg-background section-padding">
      <div className="container-custom mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-5xl font-extrabold text-center mb-4 font-heading text-foreground"
        >
          Our <span className="gradient-text">Delicious Menu</span>
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-center text-lg text-eatify-text-medium mb-16 max-w-2xl mx-auto"
        >
          Explore our wide range of mouth-watering fast food items, made with the freshest ingredients and a whole lot of love!
        </motion.p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10">
          {menuItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <MenuItemCard item={item} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MenuSection;