import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Menu, X, ShoppingCart } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const navLinks = [
    { href: '#home', label: 'Home' },
    { href: '#menu', label: 'Menu' },
    { href: '#about', label: 'About Us' },
    { href: '#testimonials', label: 'Reviews' },
    { href: '#contact', label: 'Order' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id) => {
    const element = document.getElementById(id.substring(1));
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isOpen ? 'bg-card shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container-custom mx-auto flex items-center justify-between py-4">
        <a href="#home" onClick={(e) => { e.preventDefault(); scrollToSection('#home'); }} className="text-3xl font-extrabold font-heading gradient-text">
          Eatify
        </a>
        <div className="hidden md:flex items-center space-x-6">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
              className="font-medium text-eatify-text-light hover:text-primary transition-colors"
            >
              {link.label}
            </a>
          ))}
          <Button onClick={() => scrollToSection('#contact')} className="bg-gradient-to-r from-eatify-accent-purple to-eatify-accent-blue hover:from-eatify-accent-blue hover:to-eatify-accent-purple text-white font-semibold rounded-full shadow-md hover:shadow-lg transition-all transform hover:scale-105">
            <ShoppingCart className="mr-2 h-5 w-5" /> Order Now
          </Button>
        </div>
        <div className="md:hidden">
          <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="h-7 w-7 text-eatify-text-light" /> : <Menu className="h-7 w-7 text-eatify-text-light" />}
          </Button>
        </div>
      </div>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden bg-card shadow-lg pb-4"
        >
          <div className="flex flex-col items-center space-y-4 pt-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
                className="font-medium text-eatify-text-light hover:text-primary transition-colors py-2"
              >
                {link.label}
              </a>
            ))}
            <Button onClick={() => scrollToSection('#contact')} className="w-1/2 bg-gradient-to-r from-eatify-accent-purple to-eatify-accent-blue hover:from-eatify-accent-blue hover:to-eatify-accent-purple text-white font-semibold rounded-full shadow-md hover:shadow-lg transition-all transform hover:scale-105">
              <ShoppingCart className="mr-2 h-5 w-5" /> Order Now
            </Button>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
};

export default Navbar;