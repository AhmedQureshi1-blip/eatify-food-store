import React from 'react';
import { Facebook, Instagram, Twitter, Youtube, Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  const socialLinks = [
    { icon: <Facebook className="h-6 w-6" />, href: '#' },
    { icon: <Instagram className="h-6 w-6" />, href: '#' },
    { icon: <Twitter className="h-6 w-6" />, href: '#' },
    { icon: <Youtube className="h-6 w-6" />, href: '#' },
  ];

  return (
    <footer className="bg-eatify-primary-dark text-eatify-text-medium section-padding">
      <div className="container-custom mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <p className="text-3xl font-extrabold font-heading gradient-text mb-4">Eatify</p>
            <p className="text-sm text-eatify-text-medium">
              Your favorite fast food, delivered fast, fresh, and fantastic!
            </p>
          </div>
          <div>
            <p className="text-xl font-semibold font-heading mb-6 text-eatify-text-light">Contact Us</p>
            <ul className="space-y-3">
              <li className="flex items-center">
                <MapPin className="h-5 w-5 mr-3 text-primary" />
                <span>123 Foodie Lane, Flavor Town, FT 54321</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-3 text-primary" />
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-3 text-primary" />
                <span>orders@eatify.com</span>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-xl font-semibold font-heading mb-6 text-eatify-text-light">Follow Us</p>
            <div className="flex space-x-4">
              {socialLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-eatify-secondary-dark rounded-full hover:bg-primary hover:text-white transition-colors duration-300"
                >
                  {link.icon}
                </a>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-eatify-secondary-dark pt-8 text-center">
          <p className="text-sm text-eatify-text-medium">
            &copy; {new Date().getFullYear()} Eatify. All Rights Reserved. Made with <span className="text-red-500">❤</span> by Hostinger Horizons.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;